from datetime import datetime

import mysql.connector
import pytz
from flask import Blueprint, render_template, session, request, flash, redirect, jsonify

cp = Blueprint("cp", __name__, template_folder="cp_templates")

bd = mysql.connector.connect(
    user='Medisim',
    password='K60KSH2DOXQn8BGnM3SA',
    database='CP_PORTAL',
    host='medisim-testdb.cbmmrisq24o6.us-west-2.rds.amazonaws.com',
    port=3306,
    auth_plugin='mysql_native_password',
    autocommit=True,  # Ensure autocommit is set to True
)
cursor = bd.cursor()


# If we want to test in Local
def user_time():
    current_time = datetime.now()
    formatted_time = current_time.strftime('%Y-%m-%d %H:%M:%S')
    return formatted_time


# Before deployment have to discomment this
# def user_time():
#     ist = pytz.timezone('Asia/Kolkata')  # IST time zone
#     utc_time = datetime.utcnow()
#     ist_time = utc_time.astimezone(ist)
#     formatted_time = ist_time.strftime('%Y-%m-%d %H:%M:%S')
#     return formatted_time

def get_user_ip():
    if 'X-Forwarded-For' in request.headers:
        # Use the first IP in the X-Forwarded-For header
        user_ip = request.headers['X-Forwarded-For'].split(',')[0].strip()
    else:
        # Use the default remote_addr
        user_ip = request.remote_addr
    return user_ip


# Sales Person Part Code Starts Here
@cp.route('/sales_person/home')
def sp_home():
    e_name = session.get('getNameFromUser')
    swch_rol_sql = "SELECT a.role_name, b.link FROM HRMS.additional_roles_assigned a, MTOP_MASTER.roles b WHERE " \
                   "a.emp_name = %s AND a.role_name=b.role AND a.lock_status=0 "
    cursor.execute(swch_rol_sql, (e_name,))
    swtch_roles = cursor.fetchall()

    menu_sql = "SELECT menu_name, url FROM MTOP_MASTER.menu_master WHERE lock_status=0 AND role= 'Sales_Person'"
    cursor.execute(menu_sql)
    menus = cursor.fetchall()
    print(menus)
    return render_template("sales_person_home.html", menus=menus, e_name=e_name, swtch_roles=swtch_roles)


@cp.route('/sales_person/leads')
def sp_leads():
    e_name = session.get('getNameFromUser')

    swch_rol_sql = "SELECT a.role_name, b.link FROM HRMS.additional_roles_assigned a, MTOP_MASTER.roles b WHERE " \
                   "a.emp_name = %s AND a.role_name=b.role AND a.lock_status=0 "
    cursor.execute(swch_rol_sql, (e_name,))
    swtch_roles = cursor.fetchall()

    menu_sql = "SELECT menu_name, url FROM MTOP_MASTER.menu_master WHERE lock_status=0 AND role='Sales_Person'"
    cursor.execute(menu_sql)
    menus = cursor.fetchall()
    print("Leads_Menu_Items:" + str(menus))

    clct_leads_sql = "SELECT * FROM leads"
    cursor.execute(clct_leads_sql)
    clctd_leads = cursor.fetchall()

    products_get_sql = "SELECT product_name FROM products WHERE lock_status=0 "
    cursor.execute(products_get_sql)
    prdts_for_lead = cursor.fetchall()
    prdts = [pdt[0] for pdt in prdts_for_lead]

    region_get_sql = "SELECT region FROM MTOP_MASTER.states group by region order by region"
    cursor.execute(region_get_sql)
    region_for_lead = cursor.fetchall()
    regions = [rg[0] for rg in region_for_lead]
    return render_template("leads.html", menus=menus, e_name=e_name, swtch_roles=swtch_roles, clctd_leads=clctd_leads,
                           prdts=prdts, regions=regions)


@cp.route('/get_states', methods=['POST'])
def get_states():
    selectRegion = request.form.get('selectRegion')
    get_state_sql = "SELECT state_name FROM MTOP_MASTER.states WHERE region = %s ORDER BY state_name"
    cursor.execute(get_state_sql, (selectRegion,))
    state_name = cursor.fetchall()
    states_name = [state[0] for state in state_name]
    return jsonify({'states_name': states_name})


@cp.route('/lead/creation', methods=['POST'])
def lead_creation():
    global lead_id
    cursor.execute("SELECT prefix, start_id, current_id FROM id_generation where category_name='leads' ")
    result = cursor.fetchone()
    if result:
        prefix, start_number, current_id = result
        lead_id = f"{prefix}{current_id}"
        new_current_id = int(current_id) + 1
        new_current_id_str = f"{new_current_id:03d}"
        cursor.execute("UPDATE id_generation SET current_id = %s where category_name='leads' ", (new_current_id_str,))

    if request.method == 'POST':
        lead = request.form['lead']
        region_name = request.form['region_name']
        state = request.form['state_name']
        cntct_person_name = request.form['cntct_person_name']
        cntct_number = request.form['cntct_number']
        email = request.form['email']
        designation = request.form['designation']
        int_in = request.form['int_in']
        username = session.get('username')
        approved_by = ''
        approved_timestamp = ''
        approved_ip = ''
        time = user_time()
        ip = get_user_ip()

        lead_add_sql = "INSERT INTO leads (lead_id, lead_name, region, state, contact_person_name, contact_number, " \
                       "email_id, interest_in, designation, lead_status, lock_status, created_by, timestamp, ip, " \
                       "approved_by, approved_timestamp, approved_ip) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, " \
                       "%s, %s, %s, %s, %s, %s, %s) "
        lead_add_val = (
            lead_id, lead, region_name, state, cntct_person_name, cntct_number, email, int_in, designation, 1, 0,
            username, time, ip, approved_by, approved_timestamp, approved_ip)
        cursor.execute(lead_add_sql, lead_add_val)
        bd.commit()
        flash("Lead Created Successfully")
        return redirect('/sales_person/leads')


@cp.route('/sales_person/contacts')
def sp_contacts():
    e_name = session.get('getNameFromUser')
    swch_rol_sql = "SELECT a.role_name, b.link FROM HRMS.additional_roles_assigned a, MTOP_MASTER.roles b WHERE " \
                   "a.emp_name = %s AND a.role_name=b.role AND a.lock_status=0 "
    cursor.execute(swch_rol_sql, (e_name,))
    swtch_roles = cursor.fetchall()

    menu_sql = "SELECT menu_name, url FROM MTOP_MASTER.menu_master WHERE lock_status=0 AND role = 'Sales_Person'"
    cursor.execute(menu_sql)
    menus = cursor.fetchall()

    states_sql = "SELECT state_name FROM MTOP_MASTER.states ORDER BY state_name"
    cursor.execute(states_sql)
    state_name = cursor.fetchall()
    states_in_India = [sn[0] for sn in state_name]
    clct_cntcs_cp_sql = "SELECT * FROM contacts"
    cursor.execute(clct_cntcs_cp_sql)
    clct_cntcs_cp = cursor.fetchall()
    return render_template("contacts.html", e_name=e_name, swtch_roles=swtch_roles, menus=menus,
                           states_in_India=states_in_India, clct_cntcs_cp=clct_cntcs_cp)


@cp.route('/contact_creation', methods=['POST'])
def contact_creation():
    e_name = session.get('getNameFromUser')
    if request.method == 'POST':
        cntct_name = request.form['cntct_name']
        cntct_number = request.form['cntct_number']
        designation = request.form['designation']
        ins_name = request.form['ins_name']
        state = request.form['state']
        cntct_person_email = request.form['cntct_person_email']
        username = session.get('username')

        time = user_time()
        ip = get_user_ip()

        cp_contact_insert_sql = "INSERT into contacts (name, mobile_number, designation, institute_name, state, " \
                                "email_id, lock_status, added_by, timestamp, ip_address) VALUES (%s, %s, %s, %s, %s, " \
                                "%s, %s, %s, %s, %s) "
        cp_contact_insert_val = (
            cntct_name, cntct_number, designation, ins_name, state, cntct_person_email, 0, username, time, ip)
        cursor.execute(cp_contact_insert_sql, cp_contact_insert_val)
        bd.commit()
        flash(f"Contact for {ins_name} added to the contacts repository..! ")
        return redirect('/sales_person/contacts')


# Sales Person Part Code Ends Here


# Admin Part Codes Starts Here

@cp.route('/cp_admin/home')
def cp_admin_home():
    e_name = session.get('getNameFromUser')

    swch_rol_sql = "SELECT a.role_name, b.link FROM HRMS.additional_roles_assigned a, MTOP_MASTER.roles b WHERE " \
                   "a.emp_name = %s AND a.role_name=b.role AND a.lock_status=0 "
    cursor.execute(swch_rol_sql, (e_name,))
    swtch_roles = cursor.fetchall()

    menu_sql = "SELECT menu_name, url FROM MTOP_MASTER.menu_master WHERE lock_status=0 AND role = 'CP_Admin'"
    cursor.execute(menu_sql)
    menus = cursor.fetchall()
    print(menus)
    return render_template("cp_home.html", e_name=e_name, swtch_roles=swtch_roles, menus=menus)


@cp.route('/cp_admin/products')
def products():
    e_name = session.get('getNameFromUser')

    swch_rol_sql = "SELECT a.role_name, b.link FROM HRMS.additional_roles_assigned a, MTOP_MASTER.roles b WHERE " \
                   "a.emp_name = %s AND a.role_name=b.role AND a.lock_status=0 "
    cursor.execute(swch_rol_sql, (e_name,))
    swtch_roles = cursor.fetchall()

    clct_pro_sql = "SELECT * FROM products"
    cursor.execute(clct_pro_sql)
    products = cursor.fetchall()

    menu_sql = "SELECT menu_name, url FROM MTOP_MASTER.menu_master WHERE lock_status=0 AND role = 'CP_Admin'"
    cursor.execute(menu_sql)
    menus = cursor.fetchall()
    return render_template("products.html", products=products, menus=menus, swtch_roles=swtch_roles, e_name=e_name)


@cp.route('/product/add', methods=['POST'])
def pdt_add():
    global pro_id
    cursor.execute("SELECT prefix, start_id, current_id FROM id_generation where category_name='products' ")
    result = cursor.fetchone()
    if result:
        prefix, start_number, current_id = result
        pro_id = f"{prefix}{current_id}"
        new_current_id = int(current_id) + 1
        new_current_id_str = f"{new_current_id:03d}"
        cursor.execute("UPDATE id_generation SET current_id = %s where category_name='products' ",
                       (new_current_id_str,))

    if request.method == 'POST':
        pdt_name = request.form['pdt_name']
        username = session.get('username')

        time = user_time()
        ip = get_user_ip()

        product_add_sql = "INSERT INTO products (product_id, product_name, lock_status, added_by, timestamp, ip) VALUES" \
                          "(%s, %s, %s, %s, %s, %s) "
        product_add_val = (pro_id, pdt_name, 0, username, time, ip)
        cursor.execute(product_add_sql, product_add_val)
        bd.commit()
        flash("Product Addedd Successfully")
        return redirect('/cp_admin/products')


@cp.route('/get_pdt_details', methods=['POST'])
def get_pdt_details():
    pdtName = request.form.get('pdtName')
    print(pdtName)
    change_pdt_sql_emp = "SELECT * FROM products WHERE product_name = %s"
    cursor.execute(change_pdt_sql_emp, (pdtName,))
    prdtName = cursor.fetchall()
    return jsonify({'prdtName': prdtName})


@cp.route('/pdt_status_update', methods=['POST'])
def pdt_status_update():
    if request.method == 'POST':
        update_pdt_name = request.form['update_pdt_name']
        status = request.form['status']

        status_update_sql = "UPDATE products SET lock_status = %s WHERE product_name = %s"
        cursor.execute(status_update_sql, (status, update_pdt_name))
        bd.commit()
        flash(f"Status Updated Successfully for {update_pdt_name}")
        return redirect('/cp_admin/products')


@cp.route('/cp_admin/region_allocation')
def region_allocation():
    e_name = session.get('getNameFromUser')

    swch_rol_sql = "SELECT a.role_name, b.link FROM HRMS.additional_roles_assigned a, MTOP_MASTER.roles b WHERE " \
                   "a.emp_name = %s AND a.role_name=b.role AND a.lock_status=0 "
    cursor.execute(swch_rol_sql, (e_name,))
    swtch_roles = cursor.fetchall()

    menu_sql = "SELECT menu_name, url FROM MTOP_MASTER.menu_master WHERE lock_status=0 AND role = 'CP_Admin'"
    cursor.execute(menu_sql)
    menus = cursor.fetchall()

    clct_reg_allo_sql = "SELECT a.region_name, a.state_name, a.allocated_to, b.emp_designation, b.emp_work_mail, " \
                        "b.emp_mobile FROM region_allocation a, HRMS.employee_profile b WHERE a.allocated_to = " \
                        "b.emp_name "
    cursor.execute(clct_reg_allo_sql)
    region_allocations = cursor.fetchall()

    emp_fetch_sql = "select emp_name from HRMS.employee_profile WHERE emp_designation like '%Sales Person%' "
    cursor.execute(emp_fetch_sql)
    sales_person_emp_names = cursor.fetchall()
    sales_person_emp_name = [sp[0] for sp in sales_person_emp_names]

    region_get_sql = "SELECT region FROM MTOP_MASTER.states group by region order by region"
    cursor.execute(region_get_sql)
    region_for_lead = cursor.fetchall()
    regions = [rg[0] for rg in region_for_lead]

    return render_template("region_allocation.html", e_name=e_name, swtch_roles=swtch_roles, menus=menus,
                           region_allocations=region_allocations, sales_person_emp_name=sales_person_emp_name,
                           regions=regions)


@cp.route('/region/allocation', methods=['POST'])
def rgn_allocate():
    if request.method == 'POST':
        sp_name = request.form['sp_name']
        region_name = request.form['region_name']
        state_name = request.form['state_name']
        username = session.get('username')
        time = user_time()
        ip = get_user_ip()

        allocate_insert_sql = "INSERT INTO region_allocation (region_name, state_name, allocated_to, lock_status, " \
                              "allocated_by, timestamp, ip_address) VALUES (%s, %s, %s, %s, %s, %s, %s) "
        allocate_insert_val = (region_name, state_name, sp_name, 0, username, time, ip)
        cursor.execute(allocate_insert_sql, allocate_insert_val)
        bd.commit()
        flash(f"Region allocated to {sp_name}")
        return redirect('/cp_admin/region_allocation')


@cp.route('/cp_admin/leads_generation')
def leads_gen():
    e_name = session.get('getNameFromUser')

    swch_rol_sql = "SELECT a.role_name, b.link FROM HRMS.additional_roles_assigned a, MTOP_MASTER.roles b WHERE " \
                   "a.emp_name = %s AND a.role_name=b.role AND a.lock_status=0 "
    cursor.execute(swch_rol_sql, (e_name,))
    swtch_roles = cursor.fetchall()

    menu_sql = "SELECT menu_name, url FROM MTOP_MASTER.menu_master WHERE lock_status=0 AND role = 'CP_Admin'"
    cursor.execute(menu_sql)
    menus = cursor.fetchall()

    clct_leads_sql = "SELECT * FROM leads"
    cursor.execute(clct_leads_sql)
    clctd_leads = cursor.fetchall()

    return render_template("leads_generation.html", e_name=e_name,swtch_roles=swtch_roles, menus=menus, clctd_leads=clctd_leads)


@cp.route('/cp_admin/lead_approval', methods=['POST'])
def lead_approval():
    data = request.json
    leadId = data.get('leadId')
    approve_status = data.get('approveStatus')

    response_data = {'message': 'Data received successfully'}
    return jsonify(response_data)