import boto3
from botocore.exceptions import NoCredentialsError
from flask import Blueprint, render_template, request, session, flash, redirect
import mysql.connector
from datetime import datetime
import pytz
from werkzeug.utils import secure_filename

cm = Blueprint("cm", __name__, template_folder="cms_templates")

cms = mysql.connector.connect(
    user='Medisim',
    password='K60KSH2DOXQn8BGnM3SA',
    database='Web_Site',
    host='medisim-testdb.cbmmrisq24o6.us-west-2.rds.amazonaws.com',
    port=3306,
    auth_plugin='mysql_native_password',
    autocommit=True,  # Ensure autocommit is set to True
)
cursor = cms.cursor()


# If we want to test in Local
# def get_user_time():
#     current_time = datetime.now()
#     formatted_time = current_time.strftime('%Y-%m-%d %H:%M:%S')
#     return formatted_time


# Before deployment have to discomment this
def get_user_time():
    ist = pytz.timezone('Asia/Kolkata')  # IST time zone
    utc_time = datetime.utcnow()
    ist_time = utc_time.astimezone(ist)
    formatted_time = ist_time.strftime('%Y-%m-%d %H:%M:%S')
    return formatted_time


def get_user_ip():
    if 'X-Forwarded-For' in request.headers:
        # Use the first IP in the X-Forwarded-For header
        user_ip = request.headers['X-Forwarded-For'].split(',')[0].strip()
    else:
        # Use the default remote_addr
        user_ip = request.remote_addr
    return user_ip


@cm.route('/cms_admin/home')
def cm_home():
    e_name = session.get('getNameFromUser')
    swch_rol_sql = "SELECT a.role_name, b.link FROM HRMS.additional_roles_assigned a, MTOP_MASTER.roles b WHERE " \
                   "a.emp_name = %s AND a.role_name=b.role AND a.lock_status=0 "
    cursor.execute(swch_rol_sql, (e_name,))
    swtch_roles = cursor.fetchall()

    menu_sql = "SELECT menu_name, url FROM MTOP_MASTER.menu_master WHERE lock_status=0 AND role= 'CMS_Admin'"
    cursor.execute(menu_sql)
    menus = cursor.fetchall()
    print(menus)
    return render_template("cms_home.html", e_name=e_name, swtch_roles=swtch_roles, menus=menus)


@cm.route('/cms_admin/news')
def news_home():
    e_name = session.get('getNameFromUser')
    swch_rol_sql = "SELECT a.role_name, b.link FROM HRMS.additional_roles_assigned a, MTOP_MASTER.roles b WHERE " \
                   "a.emp_name = %s AND a.role_name=b.role AND a.lock_status=0 "
    cursor.execute(swch_rol_sql, (e_name,))
    swtch_roles = cursor.fetchall()

    menu_sql = "SELECT menu_name, url FROM MTOP_MASTER.menu_master WHERE lock_status=0 AND role= 'CMS_Admin'"
    cursor.execute(menu_sql)
    menus = cursor.fetchall()

    news_sql = "SELECT * FROM news WHERE lock_status=0"
    cursor.execute(news_sql)
    news = cursor.fetchall()
    return render_template("news.html", e_name=e_name, swtch_roles=swtch_roles, menus=menus, news=news)


@cm.route('/news_creation', methods=['POST'])
def news_create():
    global news_id
    cursor.execute("SELECT prefix, start_id, current_id FROM id_generation where category_name='news' ")
    result = cursor.fetchone()
    if result:
        prefix, start_number, current_id = result
        news_id = f"{prefix}{current_id}"
        new_current_id = int(current_id) + 1
        new_current_id_str = f"{new_current_id:03d}"
        cursor.execute("UPDATE id_generation SET current_id = %s where category_name='news' ", (new_current_id_str,))
    if request.method == 'POST':
        news = request.form['news']
        news_backlink = request.form['news_backlink']
        file = request.files['news_logo']
        if file:
            # Generate a unique filename and save to S3
            filename = secure_filename(file.filename)
            s3 = boto3.client(
                's3',
                aws_access_key_id='AKIA6IY5WL6ZJ4ESQMUN',
                aws_secret_access_key='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'
            )
            s3.upload_fileobj(file, 'cms-news-logos', filename)

            # Save the S3 link to the database
            image_url = f'https://cms-news-logos.s3.amazonaws.com/{filename}'
        else:
            image_url = None
        u_name = session.get('username')
        time = get_user_time()
        ip = get_user_ip()
        news_insert_sql = "INSERT INTO news (news_id, news, link, image, lock_status, created_by, timestamp, " \
                          "ip_address) VALUES (%s, %s, %s, %s, %s, %s, %s, %s) "
        news_insert_val = (news_id, news, news_backlink, image_url, 0, u_name, time, ip)
        cursor.execute(news_insert_sql, news_insert_val)
        cms.commit()
        flash("News Created Successfully...!")
    return redirect('/cms_admin/news')
