from datetime import datetime
from io import BytesIO

from flask import Blueprint, render_template, request, redirect, flash, session, send_file
import pytz
from reportlab.pdfgen import canvas
from PyPDF2 import PdfWriter, PdfReader
import bcrypt
import mysql.connector

user_controller = Blueprint("user_controller", __name__, template_folder="login_templates")

mtm = mysql.connector.connect(
    user='Medisim',
    password='K60KSH2DOXQn8BGnM3SA',
    database='MTOP_MASTER',
    host='medisim-testdb.cbmmrisq24o6.us-west-2.rds.amazonaws.com',
    port=3306,
    auth_plugin='mysql_native_password',
    autocommit=True,
)
cursor = mtm.cursor()


def hash_password(password):
    # Generate a salt and hash the password
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password


# Function to check if the provided password matches the stored hash
def check_password(stored_hash, password):
    return bcrypt.checkpw(password.encode('utf-8'), stored_hash.encode('utf-8'))


def encrypt_pdf(pdf_content, password, output_filename):
    # Move to the beginning of the buffer
    pdf_content.seek(0)

    # Create a PDF writer object
    writer = PdfWriter()

    # Add the content to the PDF writer
    writer.add_page(PdfReader(pdf_content).pages[0])

    # Encrypt the PDF with the provided password
    writer.encrypt(password)

    # Save the encrypted PDF to the buffer
    encrypted_pdf_content = BytesIO()
    writer.write(encrypted_pdf_content)

    # Write the encrypted PDF content to the original buffer
    pdf_content.truncate(0)
    pdf_content.seek(0)
    pdf_content.write(encrypted_pdf_content.getvalue())


def generate_dynamic_password(name, emp_id):
    # Concatenate name and employee ID
    dynamic_password = f"{name}_{emp_id}"

    # Return the dynamic password
    return dynamic_password


@user_controller.route('/')
def login():
    return render_template("login.html")


@user_controller.route('/login_success', methods=['POST'])
def success():
    global username, password
    if request.method == 'POST':
        session['username'] = request.form['username']
        username = session.get('username')
        password = request.form['password']

    usersql = "SELECT user_id, password, lock_status, number_of_failure_attempts FROM user_details WHERE binary " \
              "user_id = %s and lock_status=0"
    cursor.execute(usersql, (username,))
    user = cursor.fetchone()
    if user:
        stored_hashed_password = user[1]
        current_attempts = int(user[3])
        # cur_atmpt = user[3]

        if check_password(stored_hashed_password, password):
            current_time = datetime.now()
            formatted_time = current_time.strftime('%Y-%m-%d %H:%M:%S')
            update_sql = "UPDATE user_details SET last_login_details = %s WHERE " \
                         "user_id = %s "
            cursor.execute(update_sql, (formatted_time, username))
            mtm.commit()
            return redirect('/employee')
        else:
            new_attempts = current_attempts + 1
            update_sql = "UPDATE user_details SET number_of_failure_attempts = %s WHERE user_id = %s "
            cursor.execute(update_sql, (new_attempts, username))
            mtm.commit()
            if new_attempts > 3:
                update_sql = "UPDATE user_details SET lock_status = 2 WHERE user_id = %s "
                cursor.execute(update_sql, (username,))
                mtm.commit()
            flash(f"Incorrect Password....! Limit Exceeds {current_attempts} of 3")
            return redirect('/')
    else:
        flash("Invalid User/ Account Locked....!")
        return redirect('/')


@user_controller.route('/employee')
def employee():
    global e_name
    u_name = session.get('username')
    name_extraction_sql = "SELECT b.emp_name FROM user_details a, HRMS.employee_profile b WHERE a.emp_id = b.emp_id " \
                          "AND a.user_id= %s "
    cursor.execute(name_extraction_sql, (u_name,))
    employee_name_from_user = cursor.fetchall()
    getEmployeeNameFromUser = [name_user[0] for name_user in employee_name_from_user]
    print(getEmployeeNameFromUser)
    for getNameFromUser in getEmployeeNameFromUser:
        session['getNameFromUser'] = getNameFromUser
        e_name = session.get('getNameFromUser')
    swch_rol_sql = "SELECT a.role_name, b.link FROM HRMS.additional_roles_assigned a, roles b WHERE a.emp_name = %s " \
                   "AND a.role_name=b.role AND a.lock_status=0 "
    cursor.execute(swch_rol_sql, (e_name,))
    swtch_roles = cursor.fetchall()
    return render_template("dashboard.html", u_name=e_name, swtch_roles=swtch_roles)


@user_controller.route('/company_admin')
def company_admin():
    u_name = session.get('username')
    swch_rol_sql = "SELECT a.role_name, b.link FROM HRMS.additional_roles_assigned a, roles b WHERE a.emp_name = %s " \
                   "AND a.role_name=b.role AND a.lock_status=0 "
    cursor.execute(swch_rol_sql, (u_name,))
    swtch_roles = cursor.fetchall()
    return render_template("company_admin.html", swtch_roles=swtch_roles)


@user_controller.route('/logout')
def logout():
    return render_template("login.html")


@user_controller.route('/payslip_download')
def payslip_download():
    user_name = session.get('username')
    return render_template("payslip.html", u_name=user_name)


@user_controller.route('/pdf_generated', methods=['POST'])
def pdf_generated():
    global output_filename
    if request.method == 'POST':
        date = request.form['month']
        input_date = datetime.strptime(date, "%Y-%m")
        month_name = input_date.strftime("%B")
        user_name = session.get('username')
        pay_slip_sql = "SELECT * FROM HRMS.payslip WHERE month= %s AND name= %s "
        cursor.execute(pay_slip_sql, (month_name, user_name))
        pay_details = cursor.fetchall()
        if pay_details:
            emp_id = pay_details[0][1]
            print(emp_id)
            name = pay_details[0][2]
            print(name)

            # Create a PDF using ReportLab
            pdf_content = BytesIO()
            pdf = canvas.Canvas(pdf_content)
            pdf.drawString(100, 800, f"Pay Slip for {name}")
            pdf.drawString(100, 100, f"Hi {name}")
            # Add more content to the PDF as needed
            pdf.showPage()
            pdf.save()

            # Generate a password-protected PDF
            # password = generate_dynamic_password(name, emp_id)
            output_filename = f"{month_name}_payslip.pdf"  # Dynamic filename based on month and payslip
            # encrypt_pdf(pdf_content, password, output_filename)

            # Send the file as a response for download
            pdf_content.seek(0)
            return send_file(BytesIO(pdf_content.getvalue()), as_attachment=True, download_name=output_filename,
                             mimetype='application/pdf')
        else:
            flash("No pay details found for the selected month.")
            return redirect('/payslip_download')


@user_controller.route('/attendance')
def attendance():
    u_name = session.get('username')
    att_fetch_sql = "SELECT name, date, min(attendance_timings), max(attendance_timings), TIMEDIFF(MAX(" \
                    "attendance_timings), MIN(attendance_timings)) FROM " \
                    "BIOMETRIC.face_attendance WHERE name = %s GROUP BY name, date"
    cursor.execute(att_fetch_sql, (u_name,))
    att = cursor.fetchall()
    return render_template("dashboard.html", u_name=u_name, att=att)
