from datetime import datetime
import pytz
import bcrypt
import socket
from flask import Blueprint, render_template, request, redirect, flash, session, jsonify
import mysql.connector

master = Blueprint("master", __name__, template_folder="mtop_templates")

mtm = mysql.connector.connect(
    user='Medisim',
    password='K60KSH2DOXQn8BGnM3SA',
    database='MTOP_MASTER',
    host='medisim-testdb.cbmmrisq24o6.us-west-2.rds.amazonaws.com',
    port=3306,
    auth_plugin='mysql_native_password',
    autocommit=True,
)
cursor = mtm.cursor()


def hash_password(password):
    # Generate a salt and hash the password
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password


# Function to check if the provided password matches the stored hash
def check_password(stored_hash, password):
    return bcrypt.checkpw(password.encode('utf-8'), stored_hash.encode('utf-8'))


def generate_dynamic_password(name, emp_id):
    # Concatenate name and employee ID
    dynamic_password = f"{name}_{emp_id}"

    # Return the dynamic password
    return dynamic_password


def get_local_ip():
    try:
        host_name = socket.gethostname()
        print(f"Hostname: {host_name}")
        # Get the local machine's IP address
        local_ip = socket.gethostbyname(host_name)
        print(f"Resolved IP: {local_ip}")
        return local_ip
    except Exception as e:
        print(f"Error getting local machine's IP address: {e}")
        return None


@master.route('/office_admin/users')
def users():
    u_name = session.get('username')
    e_name = session.get('getNameFromUser')
    print(e_name)

    collect_users_sql = "SELECT * FROM user_details a, HRMS.employee_profile b WHERE a.emp_id=b.emp_id"
    cursor.execute(collect_users_sql)
    clctd_users = cursor.fetchall()

    swch_rol_sql = "SELECT a.role_name, b.link FROM HRMS.additional_roles_assigned a, roles b WHERE a.emp_name = %s " \
                   "AND a.role_name=b.role AND a.lock_status=0 "
    cursor.execute(swch_rol_sql, (e_name,))
    swtch_roles = cursor.fetchall()

    menu_sql = "SELECT menu_name, url FROM menu_master WHERE lock_status=0 AND role='Office_Admin'"
    cursor.execute(menu_sql)
    menus = cursor.fetchall()

    emps_sql = "SELECT emp_name FROM HRMS.employee_profile WHERE lock_status=0 "
    cursor.execute(emps_sql)
    emps_name = cursor.fetchall()
    emp_namess = [emp[0] for emp in emps_name]

    return render_template("user_creation.html", swtch_roles=swtch_roles, menus=menus, e_name=e_name,
                           emp_namess=emp_namess, clctd_users=clctd_users)


@master.route('/office_admin/user_creation', methods=['POST'])
def user_creation():
    global employee_id
    if request.method == 'POST':
        employee_name = request.form['empss']

        user_id = request.form['user_id']
        password = request.form['password']
        encrypted_password = hash_password(password)
        print(encrypted_password)
        # If we want to test in Local
        current_time = datetime.now()
        formatted_time = current_time.strftime('%Y-%m-%d %H:%M:%S')
        time = formatted_time

        # Before deploying has to discomment this
        # ist = pytz.timezone('Asia/Kolkata')  # IST time zone
        # utc_time = datetime.utcnow()
        # ist_time = utc_time.astimezone(ist)
        # time = ist_time.strftime('%Y-%m-%d %H:%M:%S')

        ip = request.remote_addr
        number_of_failure_attempts = 0
        last_login_details = " "
        username = "Sam"
        emp_id_get = "SELECT emp_id FROM HRMS.employee_profile WHERE emp_name = %s AND lock_status=0"
        cursor.execute(emp_id_get, (employee_name,))
        emp_id = cursor.fetchall()
        employeee_id = [eid[0] for eid in emp_id]
        for employee_id in employeee_id:
            print(employee_id)
        user_add_sql = """INSERT INTO user_details(emp_id, user_id, password, lock_status, number_of_failure_attempts, 
        last_login_details, created_by, timestamp, ip_address) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s) """
        user_add_val = (
            employee_id, user_id, encrypted_password, 0, number_of_failure_attempts, last_login_details, username, time,
            ip)
        cursor.execute(user_add_sql, user_add_val)
        mtm.commit()
        flash("User Created Successfully..!")
    return redirect("/office_admin/users")


@master.route('/office_admin/roles')
def roles_add():
    e_name = session.get('getNameFromUser')
    collect_roles_sql = "SELECT * FROM roles"
    cursor.execute(collect_roles_sql)
    clctd_roles = cursor.fetchall()

    swch_rol_sql = "SELECT a.role_name, b.link FROM HRMS.additional_roles_assigned a, roles b WHERE a.emp_name = %s " \
                   "AND a.role_name=b.role AND a.lock_status=0 "
    cursor.execute(swch_rol_sql, (e_name,))
    swtch_roles = cursor.fetchall()

    menu_sql = "SELECT menu_name, url FROM menu_master WHERE lock_status=0 AND role='Office_Admin'"
    cursor.execute(menu_sql)
    menus = cursor.fetchall()
    dept_names_sql = "SELECT department_name FROM departments WHERE lock_status=0"
    cursor.execute(dept_names_sql)
    depts = cursor.fetchall()
    dept_for_role_creation = [dfr[0] for dfr in depts]
    return render_template("roles.html", e_name=e_name, clctd_roles=clctd_roles, menus=menus,
                           dept_for_role_creation=dept_for_role_creation, swtch_roles=swtch_roles)


@master.route('/roles', methods=['post'])
def roles():
    global role_id
    cursor = mtm.cursor()
    cursor.execute("SELECT prefix, start_id, current_id FROM id_generation where category_name='role' ")
    result = cursor.fetchone()
    if result:
        prefix, start_number, current_id = result
        role_id = f"{prefix}{current_id}"
        new_current_id = int(current_id) + 1
        new_current_id_str = f"{new_current_id:03d}"
        cursor.execute("UPDATE id_generation SET current_id = %s where category_name='role' ", (new_current_id_str,))

    if request.method == 'POST':
        role = request.form['role']
        deptt = request.form['deptt']
        username = session.get('username')
        # If we want to test in Local
        # current_time = datetime.now()
        # formatted_time = current_time.strftime('%Y-%m-%d %H:%M:%S')
        # time = formatted_time

        # Before deploying has to discomment this
        ist = pytz.timezone('Asia/Kolkata')  # IST time zone
        utc_time = datetime.utcnow()
        ist_time = utc_time.astimezone(ist)
        time = ist_time.strftime('%Y-%m-%d %H:%M:%S')

        ip = request.remote_addr

        cursor = mtm.cursor()

        role_sql = """INSERT INTO roles(role_id, role, department, lock_status, created_by, timestamp, ip_address) 
                VALUES(%s, %s, %s, %s, %s, %s, %s) """
        role_val = (role_id, role, deptt, 0, username, time, ip)
        cursor.execute(role_sql, role_val)
        mtm.commit()
        cursor.close()
        flash("Role Created Successfully..!")
    return redirect("/office_admin/roles")


@master.route('/office_admin/departments')
def dept_add():
    e_name = session.get('getNameFromUser')
    collect_depts_sql = "SELECT * FROM departments WHERE lock_status=0 "
    cursor.execute(collect_depts_sql)
    clctd_depts = cursor.fetchall()

    swch_rol_sql = "SELECT a.role_name, b.link FROM HRMS.additional_roles_assigned a, roles b WHERE a.emp_name = %s " \
                   "AND a.role_name=b.role AND a.lock_status=0 "
    cursor.execute(swch_rol_sql, (e_name,))
    swtch_roles = cursor.fetchall()

    menu_sql = "SELECT menu_name, url FROM menu_master WHERE lock_status=0 AND role='Office_Admin'"
    cursor.execute(menu_sql)
    menus = cursor.fetchall()
    return render_template("department.html", e_name=e_name, swtch_roles=swtch_roles, clctd_depts=clctd_depts,
                           menus=menus)


@master.route('/departments', methods=['post'])
def departments():
    global dept_id
    cursor = mtm.cursor()
    cursor.execute("SELECT prefix, start_id, current_id FROM id_generation where category_name='department' ")
    result = cursor.fetchone()
    if result:
        prefix, start_number, current_id = result
        dept_id = f"{prefix}{current_id}"
        new_current_id = int(current_id) + 1
        new_current_id_str = f"{new_current_id:03d}"
        cursor.execute("UPDATE id_generation SET current_id = %s where category_name='department' ",
                       (new_current_id_str,))

    if request.method == 'POST':
        department = request.form['department']
        username = session.get('username')
        # If we want to test in Local
        # current_time = datetime.now()
        # formatted_time = current_time.strftime('%Y-%m-%d %H:%M:%S')
        # time = formatted_time

        # Before deploying has to discomment this
        ist = pytz.timezone('Asia/Kolkata')  # IST time zone
        utc_time = datetime.utcnow()
        ist_time = utc_time.astimezone(ist)
        time = ist_time.strftime('%Y-%m-%d %H:%M:%S')

        ip = request.remote_addr

        cursor = mtm.cursor()

        role_sql = """INSERT INTO departments(department_id, department_name, lock_status, created_by, timestamp, ip_address) 
                VALUES(%s, %s, %s, %s, %s, %s) """
        role_val = (dept_id, department, 0, username, time, ip)
        cursor.execute(role_sql, role_val)
        mtm.commit()
        cursor.close()
        flash("Department Created Successfully..!")
    return redirect("/office_admin/departments")


@master.route('/admin/master')
def admin_master():
    e_name = session.get('getNameFromUser')
    role_for_menu_sql = "SELECT role FROM roles WHERE lock_status=0 "
    cursor.execute(role_for_menu_sql)
    role_for_menus = cursor.fetchall()
    menu_roles = [mr[0] for mr in role_for_menus]
    menus_sql = "SELECT * FROM menu_master"
    cursor.execute(menus_sql)
    menuss = cursor.fetchall()

    swch_rol_sql = "SELECT a.role_name, b.link FROM HRMS.additional_roles_assigned a, roles b WHERE a.emp_name = %s " \
                   "AND a.role_name=b.role AND a.lock_status=0 "
    cursor.execute(swch_rol_sql, (e_name,))
    swtch_roles = cursor.fetchall()

    menu_sql = "SELECT menu_name, url FROM menu_master WHERE lock_status=0 AND role='Office_Admin'"
    cursor.execute(menu_sql)
    menus = cursor.fetchall()
    return render_template("menus.html", e_name=e_name, swtch_roles=swtch_roles, menu_roles=menu_roles, menuss=menuss,
                           menus=menus)


@master.route('/office_admin/menu')
def menu_add():
    e_name = session.get('getNameFromUser')
    role_for_menu_sql = "SELECT role FROM roles WHERE lock_status=0 "
    cursor.execute(role_for_menu_sql)
    role_for_menus = cursor.fetchall()
    menu_roles = [mr[0] for mr in role_for_menus]
    menus_sql = "SELECT * FROM menu_master"
    cursor.execute(menus_sql)
    menuss = cursor.fetchall()
    menu_sql = "SELECT menu_name, url FROM menu_master WHERE lock_status=0 AND role='Office_Admin'"
    cursor.execute(menu_sql)
    menus = cursor.fetchall()

    swch_rol_sql = "SELECT a.role_name, b.link FROM HRMS.additional_roles_assigned a, roles b WHERE a.emp_name = %s " \
                   "AND a.role_name=b.role AND a.lock_status=0 "
    cursor.execute(swch_rol_sql, (e_name,))
    swtch_roles = cursor.fetchall()

    return render_template("menus.html", e_name=e_name, swtch_roles=swtch_roles, menu_roles=menu_roles, menuss=menuss,
                           menus=menus)


@master.route('/menu_creation', methods=['POST'])
def create_menu():
    global menu_id
    cursor.execute("SELECT prefix, start_id, current_id FROM id_generation where category_name='menu' ")
    result = cursor.fetchone()
    if result:
        prefix, start_number, current_id = result
        menu_id = f"{prefix}{current_id}"
        new_current_id = int(current_id) + 1
        new_current_id_str = f"{new_current_id:03d}"
        cursor.execute("UPDATE id_generation SET current_id = %s where category_name='menu' ", (new_current_id_str,))
    if request.method == 'POST':
        menu = request.form['menu_name']
        role = request.form['role']
        role_name = role.replace(" ", "_")
        concat_role = role.replace(" ", "_").lower()
        concat_menu = menu.replace(" ", "_").lower()
        url = f"/{concat_role}/{concat_menu}"
        username = session.get('username')

        # If we want to test in Local
        # current_time = datetime.now()
        # formatted_time = current_time.strftime('%Y-%m-%d %H:%M:%S')
        # time = formatted_time

        # Before deploying has to discomment this
        ist = pytz.timezone('Asia/Kolkata')  # IST time zone
        utc_time = datetime.utcnow()
        ist_time = utc_time.astimezone(ist)
        time = ist_time.strftime('%Y-%m-%d %H:%M:%S')

        # ip = request.remote_addr
        ip = get_local_ip()

        menu_insert_sql = "INSERT INTO menu_master (menu_id, menu_name, url, role, lock_status, created_by, " \
                          "time_stamp, ip_address) VALUES (%s, %s, %s, %s,%s, %s, %s, %s) "
        menu_insert_val = (menu_id, menu, url, role_name, 0, username, time, ip)
        cursor.execute(menu_insert_sql, menu_insert_val)
        mtm.commit()
        flash("Menu Created Successfully...!")
        return redirect('/office_admin/menu')


@master.route('/get_menu_details', methods=['POST'])
def get_menu_details():
    menuName = request.form.get('menuName')
    print(menuName)
    move_emp_sql_emp = "SELECT * FROM menu_master WHERE menu_name LIKE %s"
    cursor.execute(move_emp_sql_emp, (f'%{menuName}%',))
    menName = cursor.fetchall()
    return jsonify({'menName': menName})


@master.route('/menu_status_update', methods=['POST'])
def menu_status_update():
    if request.method == 'POST':
        change_menu_name = request.form['change_menu_name']
        status = request.form['status']

        status_update_sql = "UPDATE menu_master SET lock_status = %s WHERE menu_name = %s"
        cursor.execute(status_update_sql, (status, change_menu_name))
        mtm.commit()
        flash(f"Status Updated Successfully for {change_menu_name}")
        return redirect('/office_admin/menu')


@master.route('/get_deptt_details', methods=['POST'])
def get_dept_details():
    deptName = request.form.get('deptName')
    dept_ajax_sql = "SELECT * FROM departments WHERE menu_name LIKE %s"
    cursor.execute(dept_ajax_sql, (f'%{deptName}%',))
    dptName = cursor.fetchall()
    return jsonify({'dptName': dptName})


@master.route('/dept_status_update', methods=['POST'])
def dept_status_update():
    if request.method == 'POST':
        change_dept_name = request.form['change_dept_name']
        status = request.form['status']
        status_update_sql = "UPDATE departments SET lock_status = %s WHERE department_name = %s"
        cursor.execute(status_update_sql, (status, change_dept_name))
        mtm.commit()
        flash(f"Status Updated Successfully for <b>{change_dept_name}</b>")
        return redirect('/office_admin/departments')


@master.route('/get_role_details', methods=['POST'])
def get_role_details():
    roleName = request.form.get('roleName')
    role_ajax_sql = "SELECT * FROM roles WHERE role LIKE %s"
    cursor.execute(role_ajax_sql, (f'%{roleName}%',))
    rolName = cursor.fetchall()
    return jsonify({'rolName': rolName})


@master.route('/role_status_update', methods=['POST'])
def role_status_update():
    if request.method == 'POST':
        change_role_name = request.form['change_role_name']
        status = request.form['status']
        status_update_sql = "UPDATE roles SET lock_status = %s WHERE role = %s"
        cursor.execute(status_update_sql, (status, change_role_name))
        mtm.commit()
        flash(f"Status Updated Successfully for {change_role_name}")
        return redirect('/office_admin/roles')


@master.route('/get_user_details', methods=['POST'])
def get_user_details():
    user_id = request.form.get('user_id')
    user_ajax_sql = "SELECT * FROM user_details WHERE user_id LIKE %s"
    cursor.execute(user_ajax_sql, (f'%{user_id}%',))
    usrName = cursor.fetchall()
    return jsonify({'usrName': usrName})


@master.route('/user_status_update', methods=['POST'])
def user_status_update():
    if request.method == 'POST':
        change_user_id = request.form['change_user_id']
        status = request.form['status']
        print(status)
        status_update_sql = "UPDATE user_details SET lock_status = %s WHERE user_id = %s"
        cursor.execute(status_update_sql, (status, change_user_id))
        mtm.commit()
        if status == '0':
            flash(f"Account unlocked for {change_user_id}")
        else:
            flash(f"Account locked for {change_user_id}")
        return redirect("/office_admin/users")
