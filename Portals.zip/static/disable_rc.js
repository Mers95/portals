//
//// <!--Have to do discomment before deploying-->
//// Right Click and F12 Disbled Start has to add while Deploying the Portal
//        // Disable right-click
//        document.addEventListener('contextmenu', function (e) {
//            e.preventDefault();
//        });
//        // Disable F12 key
//        document.addEventListener('keydown', function (e) {
//            if (e.key === 'F12' || e.key === 'F10' || e.keyCode === 123) {
//                e.preventDefault();
//            }
//        });
//
